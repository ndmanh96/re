<?
	header("Location: alerts.php");
?>
